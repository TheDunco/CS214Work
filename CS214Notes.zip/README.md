# CS214Work
CS214 work/notes

Use VSCode or some editor with colorizing or something for readability.
I use VSCode with a bracket pair colorizer and indent colorizer. 

"<>" are used to indicate that I filled something in from the slides.

"[]" are used later on to denote notes, things said out loud or written on the board.